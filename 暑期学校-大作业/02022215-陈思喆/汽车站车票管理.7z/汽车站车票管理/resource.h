﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 stManagement.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STMANAGEMENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_AdminLogin           130
#define IDD_DIALOG_PasWin               131
#define IDD_DIALOG_PasLogin             132
#define IDD_DIALOG_TicketService        133
#define IDD_DIALOG_CheckBusInfo         134
#define IDD_DIALOG_AdminWin             135
#define IDD_DIALOG_AllBusInfo           136
#define IDD_DIALOG_DelBus               137
#define IDD_DIALOG_AddBusInfo           138
#define IDD_DIALOG_Guide                139
#define IDD_DIALOG_FileMissing          141
#define IDD_DIALOG_Ticketing            142
#define IDD_DIALOG_CheckoutForTicketing 143
#define IDD_DIALOG_CheckoutForReturnTicket 144
#define IDD_DIALOG_ReturnTicket         145
#define IDD_DIALOG_ExistedBusInfo       146
#define IDB_BITMAP1                     146
#define IDD_DIALOG_Operation            147
#define IDC_BUTTON_ToPasWin             1000
#define IDC_BUTTON_ToGuide              1001
#define IDC_BUTTON_ToAdminLogin         1002
#define IDC_EDIT1                       1004
#define IDC_EDIT_AdminName              1004
#define IDC_EDIT_DB                     1004
#define IDC_EDIT2                       1005
#define IDC_EDIT_AdminPW                1005
#define IDC_BUTTON_NextStepToAdminWin   1006
#define IDC_BUTTON_ToTicketService      1009
#define IDC_EDIT_PasName                1011
#define IDC_BUTTON_ToTicketing          1013
#define IDC_BUTTON_ToReturnTicket       1014
#define IDC_BUTTON_Home                 1015
#define IDC_BUTTON_BackToPasWin         1016
#define IDC_BUTTON_NextStepToTicketService 1017
#define IDC_BUTTON_ToCheckBusInfo       1018
#define IDC_BUTTON_ToAddBusInfo         1019
#define IDC_BUTTON_ToExistedBusInfo     1019
#define IDC_BUTTON_ToAllBusInfo         1020
#define IDC_BUTTON_ToDelBus             1021
#define IDC_STATIC_ERROR                1022
#define IDC_STATIC_ERROR2               1023
#define IDC_STATIC_WelcomePas           1024
#define IDC_STATIC_Time                 1025
#define IDC_BUTTON_Ok                   1027
#define IDC_BUTTON_Cancel2              1028
#define IDC_LIST_CheckBusInfo           1029
#define IDC_LIST_DelBus                 1030
#define IDC_EDIT_AddBusInfoNum          1031
#define IDC_EDIT_AddBusInfoTime         1032
#define IDC_EDIT_AddBusInfoMinute       1032
#define IDC_EDIT_AddBusInfoStartS       1033
#define IDC_EDIT_AddBusInfoEndS         1034
#define IDC_EDIT_AddBusInfoExpect       1035
#define IDC_EDIT_AddBusInfoPrice        1036
#define IDC_EDIT_AddBusInfoMaxPas       1037
#define IDC_EDIT_AddBusInfoSold         1038
#define IDC_BUTTON_Cancel               1039
#define IDC_LIST_AllBusInfo             1040
#define IDC_EDIT_AddBusInfoHour         1040
#define IDC_EDIT_CBI                    1041
#define IDC_BUTTON_Check                1042
#define IDC_LIST_Ticketing              1044
#define IDC_BUTTON_Buy                  1045
#define IDC_EDIT_Buy                    1046
#define IDC_EDIT_Return                 1047
#define IDC_BUTTON_Return               1048
#define IDC_LIST_ReturnTicket           1049
#define IDB_BITMAP                      1051
#define IDC_LIST_ExistedBusInfo         1052
#define IDC_BUTTON_Del                  1053
#define IDC_BUTTON_Operation            1054
#define IDC_LIST_Operation              1055
#define IDC_STATIC_WelcomeAdmin         65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
